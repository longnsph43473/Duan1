### Cấu trúc thư mục

## Root
1. admin
    
    - controllers
    - models
    - views
    - index.php

2. commons // File dùng chung cả dự án
3. uploads // Folder lưu trữ file upload

// Dưới đây: 4 5 6 7 thuộc về Client

4. controllers
5. models
6. views
7. index.php

- Không có thư mục client và chỉ có thư mục admin vì mình không muốn trên url có /client nên đặt MVC của client trực tiếp trong root
- Admin có thư mục riêng với đầy đủ MVC để trên url có /admin.
- Cấu hình DB trong file commons/env.php