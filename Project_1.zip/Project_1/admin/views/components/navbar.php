<nav class="navbar navbar-expand-sm bg-light">
    <div class="container-fluid">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL_ADMIN ?>">Trang chủ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= BASE_URL_ADMIN ?>?act=product-list">Quản lý sản phẩm</a>
            </li>
        </ul>
    </div>
</nav>