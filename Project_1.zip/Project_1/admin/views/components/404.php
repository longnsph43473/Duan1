<div class="container-fluid pt-4 px-4">
    <div class="row vh-100 bg-lightrounded align-items-center justify-content-center mx-0 ">
        <div class="col-md-6 text-center p-4">
            <i class="bi bi-exclamation-triangle display-1 text-primary"></i>
            <h2 class="display-1 fw-bold">404</h2>
            <h2 class="mb-4">Không tìm thấy trang</h2>
            <h2>Rất tiếc,trang bạn tìm kiếm không tồn tại</h2>
            <a href="btn btn-primary rounded-pill py-3 px-5 " href="">Quay lại trang chủ</a>
        </div>
    </div>
</div>