<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo BASE_URL_ADMIN . "public/css/style.css" ?>">
    <title>Document</title>
</head>
<body>
    <footer>
        <p>Welcom to EASE Shop</p>
    </footer>
</body>
</html>