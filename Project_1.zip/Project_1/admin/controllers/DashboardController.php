<?php 

class DashboardController
{
    public function dashboard() {
        require_once './views/dashboard.php';
    }
}