<?php 

class HomeController
{
    // public $modelProduct;

    public function __construct() {
      
    }

    public function home() {
       

        require_once './views/home.php';
    }
}